UNDERLORDS CRAZY OFFLINE — SIMPLE MAC TESTER

This is the same Crazy build: 85 heroes, 76 items, and recovered appearance
files for the four retired heroes. It requires only Steam and standalone
Underlords; no Python or other runtime needs to be installed.

1. Close Underlords.
2. Double-click Crazy-Install-and-Play.command.
3. Play a new Standard/Easy bot match.
4. Close Underlords.
5. Double-click Crazy-Restore.command.

The installer checks the exact supported build, creates backups, refuses
asset conflicts, and launches the game with -dac_offline. Restore verifies
managed files before returning the original definitions. Keep this folder
until restoration is complete. This is offline-only and does not alter
Steam authentication, VAC, matchmaking, or the game executable.

If macOS blocks a command file, Finder > right-click > Open is sufficient.
Do not disable Gatekeeper. If the game is in a nonstandard Steam location,
the installer asks for its folder.
