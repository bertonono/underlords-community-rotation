#!/bin/bash
set -u
cd -- "$(dirname -- "$0")" || exit 1
BASE="$PWD"; STATE="$BASE/state"
fail(){ echo "REFUSED: $1"; read -r -p "Press Return to close. "; exit 1; }
hash(){ shasum -a 256 "$1" | awk '{print $1}'; }
[ "$(cat "$STATE/status" 2>/dev/null)" = applied ] || fail "This package is not marked as applied."
if pgrep -x underlords >/dev/null 2>&1; then fail "Close Underlords before restoring."; fi
ROOT="$(cat "$STATE/root")"; UNITS="$ROOT/game/dac/scripts/units.vdacdefs_c"; ITEMS="$ROOT/game/dac/scripts/items.vdacdefs_c"
ORIG_UNITS="a67aaa9c2445240a1f15c16f957590adcdd4f4d8f76d07ac62a4a99d9e8fccbd"; ORIG_ITEMS="11756141d44811614684f5e1c5f34d837581b794b43dcda999316325dc22d8a8"
CAND_UNITS="1a17d0106b4569592dd46f84ab0bca5c4579bd70261671742827d26384938711"; CAND_ITEMS="bfeff2b8fb90749079dcb1669bc297b142fb9b300e7b2527631eeca58e142245"
[ "$(hash "$STATE/units.original.vdacdefs_c")" = "$ORIG_UNITS" ] || fail "Units backup hash mismatch."
[ "$(hash "$STATE/items.original.vdacdefs_c")" = "$ORIG_ITEMS" ] || fail "Items backup hash mismatch."
[ "$(hash "$UNITS")" = "$CAND_UNITS" ] || fail "Managed units file changed unexpectedly."
[ "$(hash "$ITEMS")" = "$CAND_ITEMS" ] || fail "Managed items file changed unexpectedly."
while read -r rel; do
  [ -n "$rel" ] || continue
  dest="$ROOT/game/dac/$rel"; [ -f "$dest" ] || fail "Managed asset is missing: $rel"
  expected="$(awk -v p="$rel" '$2==p {print $1}' "$BASE/appearance/assets.sha256")"
  [ "$(hash "$dest")" = "$expected" ] || fail "Managed asset changed unexpectedly: $rel"
done < "$STATE/assets-installed"
cp -p "$STATE/units.original.vdacdefs_c" "$UNITS" || fail "Units restore failed."
cp -p "$STATE/items.original.vdacdefs_c" "$ITEMS" || fail "Items restore failed."
while read -r rel; do [ -n "$rel" ] && rm -f "$ROOT/game/dac/$rel"; done < "$STATE/assets-installed"
printf 'restored\n' > "$STATE/status"
echo "Original Underlords files restored."
read -r -p "Press Return to close. "
