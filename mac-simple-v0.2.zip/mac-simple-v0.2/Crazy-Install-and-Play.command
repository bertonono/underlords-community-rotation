#!/bin/bash
set -u
cd -- "$(dirname -- "$0")" || exit 1
BASE="$PWD"
STATE="$BASE/state"
ROOT="${UNDERLORDS_ROOT:-$HOME/Library/Application Support/Steam/steamapps/common/Underlords}"
UNITS_REL="game/dac/scripts/units.vdacdefs_c"
ITEMS_REL="game/dac/scripts/items.vdacdefs_c"
ORIG_UNITS="a67aaa9c2445240a1f15c16f957590adcdd4f4d8f76d07ac62a4a99d9e8fccbd"
ORIG_ITEMS="11756141d44811614684f5e1c5f34d837581b794b43dcda999316325dc22d8a8"
CAND_UNITS="1a17d0106b4569592dd46f84ab0bca5c4579bd70261671742827d26384938711"
CAND_ITEMS="bfeff2b8fb90749079dcb1669bc297b142fb9b300e7b2527631eeca58e142245"
hash(){ shasum -a 256 "$1" | awk '{print $1}'; }
rollback(){
  if [ "$(cat "$STATE/status" 2>/dev/null)" = preparing ]; then
    [ -f "$STATE/units.original.vdacdefs_c" ] && cp -p "$STATE/units.original.vdacdefs_c" "$ROOT/$UNITS_REL" 2>/dev/null || true
    [ -f "$STATE/items.original.vdacdefs_c" ] && cp -p "$STATE/items.original.vdacdefs_c" "$ROOT/$ITEMS_REL" 2>/dev/null || true
    while IFS= read -r rel; do [ -n "$rel" ] && rm -f "$ROOT/game/dac/$rel"; done < "$STATE/assets-installed" 2>/dev/null || true
    printf 'rolled-back\n' > "$STATE/status"
  fi
}
fail(){ echo "REFUSED: $1"; rollback; read -r -p "Press Return to close. "; exit 1; }
if ! command -v shasum >/dev/null 2>&1; then fail "macOS shasum is unavailable."; fi
if ! pgrep -x underlords >/dev/null 2>&1; then :; else fail "Close Underlords before installing."; fi
if [ ! -f "$ROOT/$UNITS_REL" ]; then
  read -r -p "Enter the Underlords installation folder: " ROOT
fi
[ -f "$ROOT/$UNITS_REL" ] || fail "Underlords installation was not found."
[ -f "$ROOT/$ITEMS_REL" ] || fail "Underlords item definitions were not found."
[ -f "$STATE/status" ] && [ "$(cat "$STATE/status")" = applied ] && fail "This package is already applied; restore it first."
[ "$(hash "$ROOT/$UNITS_REL")" = "$ORIG_UNITS" ] || fail "Unexpected Underlords build or units hash. Nothing was changed."
[ "$(hash "$ROOT/$ITEMS_REL")" = "$ORIG_ITEMS" ] || fail "Unexpected Underlords build or items hash. Nothing was changed."
[ "$(hash "$BASE/candidates/units.vdacdefs_c")" = "$CAND_UNITS" ] || fail "Package units hash mismatch."
[ "$(hash "$BASE/candidates/items.vdacdefs_c")" = "$CAND_ITEMS" ] || fail "Package items hash mismatch."
while read -r expected rel; do
  [ -n "$rel" ] || continue
  source="$BASE/appearance/files/$rel"; dest="$ROOT/game/dac/$rel"
  [ -f "$source" ] || fail "Package asset is missing: $rel"
  [ "$(hash "$source")" = "$expected" ] || fail "Package asset hash mismatch: $rel"
  [ ! -e "$dest" ] || fail "Existing asset conflict: $dest"
done < "$BASE/appearance/assets.sha256"
mkdir -p "$STATE"
cp -p "$ROOT/$UNITS_REL" "$STATE/units.original.vdacdefs_c" || fail "Could not create units backup."
cp -p "$ROOT/$ITEMS_REL" "$STATE/items.original.vdacdefs_c" || fail "Could not create items backup."
[ "$(hash "$STATE/units.original.vdacdefs_c")" = "$ORIG_UNITS" ] || fail "Units backup verification failed."
[ "$(hash "$STATE/items.original.vdacdefs_c")" = "$ORIG_ITEMS" ] || fail "Items backup verification failed."
printf '%s\n' "$ROOT" > "$STATE/root"
printf 'preparing\n' > "$STATE/status"
cp -p "$BASE/candidates/units.vdacdefs_c" "$ROOT/$UNITS_REL" || fail "Units installation failed."
cp -p "$BASE/candidates/items.vdacdefs_c" "$ROOT/$ITEMS_REL" || fail "Items installation failed."
: > "$STATE/assets-installed"
while read -r expected rel; do
  [ -n "$rel" ] || continue
  dest="$ROOT/game/dac/$rel"
  mkdir -p "$(dirname "$dest")" || fail "Could not create asset directory."
  cp -p "$BASE/appearance/files/$rel" "$dest" || fail "Asset installation failed: $rel"
  printf '%s\n' "$rel" >> "$STATE/assets-installed"
done < "$BASE/appearance/assets.sha256"
[ "$(hash "$ROOT/$UNITS_REL")" = "$CAND_UNITS" ] || fail "Installed units verification failed."
[ "$(hash "$ROOT/$ITEMS_REL")" = "$CAND_ITEMS" ] || fail "Installed items verification failed."
printf 'applied\n' > "$STATE/status"
echo "Crazy offline build applied. Launching Underlords in offline/bot mode."
bash "$ROOT/game/underlords.sh" -dac_offline
