UNDERLORDS CRAZY OFFLINE — SIMPLE WINDOWS TESTER

This is the same successful Crazy build: 85 heroes, 76 items, and recovered
appearance files for the four retired heroes. It requires only Steam and
standalone Underlords. No Python or other runtime needs to be installed.

1. Close Underlords.
2. Double-click Crazy-Install-and-Play.cmd.
3. Play a new Standard/Easy bot match.
4. Close Underlords.
5. Double-click Crazy-Restore.cmd when finished.

The installer checks the exact supported build, makes backups, refuses asset
conflicts, and launches Steam with -dac_offline. Restore verifies every
managed file before returning the original definitions. It does not change
Steam settings, authentication, VAC, matchmaking, or PowerShell policy
permanently. The CMD wrapper uses a process-only PowerShell invocation so the
tester does not need Python or a separate installer.

If the game is installed in a nonstandard Steam library, set UNDERLORDS_ROOT
to the Underlords installation folder before running the CMD file, or enter
the folder when prompted. Keep this folder until you have restored the game.
