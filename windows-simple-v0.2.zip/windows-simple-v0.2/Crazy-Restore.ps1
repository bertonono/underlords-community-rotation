$ErrorActionPreference = 'Stop'
$Base = Split-Path -Parent $MyInvocation.MyCommand.Path
$StatePath = Join-Path $Base 'state\install.json'
function Hash($Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
try {
  if (Get-Process -Name underlords -ErrorAction SilentlyContinue) { throw 'Close Underlords before restoring.' }
  if (!(Test-Path $StatePath)) { throw 'No installation state was found.' }
  $s = Get-Content $StatePath -Raw | ConvertFrom-Json
  if ($s.status -ne 'applied') { throw 'This package is not marked as applied.' }
  $units = Join-Path $s.root $s.units; $items = Join-Path $s.root $s.items
  $bu = Join-Path $Base 'state\units.original.vdacdefs_c'; $bi = Join-Path $Base 'state\items.original.vdacdefs_c'
  if ((Hash $bu) -ne $s.original_units -or (Hash $bi) -ne $s.original_items) { throw 'Backup hash mismatch. Nothing was changed.' }
  if ((Hash $units) -ne $s.candidate_units -or (Hash $items) -ne $s.candidate_items) { throw 'Managed definition file changed unexpectedly. Nothing was changed.' }
  foreach ($asset in $s.assets) {
    $p = Join-Path $s.root ('game\dac\' + ($asset.path -replace '/', '\'))
    if (!(Test-Path $p)) { throw "Managed asset is missing: $($asset.path)" }
    if ((Hash $p) -ne $asset.sha256) { throw "Managed asset changed unexpectedly: $($asset.path)" }
  }
  Copy-Item $bu $units -Force; Copy-Item $bi $items -Force
  foreach ($asset in $s.assets) { $p = Join-Path $s.root ('game\dac\' + ($asset.path -replace '/', '\')); Remove-Item $p -Force }
  $s.status = 'restored'; $s | ConvertTo-Json -Depth 8 | Set-Content $StatePath -Encoding UTF8
  Write-Host 'Original Underlords files restored.' -ForegroundColor Green
} catch { Write-Host ('REFUSED: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }
