$ErrorActionPreference = 'Stop'

$Base = Split-Path -Parent $MyInvocation.MyCommand.Path
$StateDir = Join-Path $Base 'state'
$StatePath = Join-Path $StateDir 'install.json'
$UnitsRel = 'game\dac\scripts\units.vdacdefs_c'
$ItemsRel = 'game\dac\scripts\items.vdacdefs_c'
$OriginalUnits = 'a67aaa9c2445240a1f15c16f957590adcdd4f4d8f76d07ac62a4a99d9e8fccbd'
$OriginalItems = '11756141d44811614684f5e1c5f34d837581b794b43dcda999316325dc22d8a8'
$CandidateUnits = '1a17d0106b4569592dd46f84ab0bca5c4579bd70261671742827d26384938711'
$CandidateItems = 'bfeff2b8fb90749079dcb1669bc297b142fb9b300e7b2527631eeca58e142245'

function Hash($Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Stop-IfRunning {
  if (Get-Process -Name underlords -ErrorAction SilentlyContinue) { throw 'Close Underlords before installing or restoring.' }
}
function Find-Game {
  $roots = @()
  if ($env:UNDERLORDS_ROOT) { $roots += $env:UNDERLORDS_ROOT }
  $roots += (Join-Path ${env:ProgramFiles(x86)} 'Steam\steamapps\common\Underlords')
  $roots += (Join-Path $env:ProgramFiles 'Steam\steamapps\common\Underlords')
  foreach ($candidate in $roots) {
    if ($candidate -and (Test-Path (Join-Path $candidate $UnitsRel))) { return (Resolve-Path $candidate).Path }
  }
  $manual = Read-Host 'Underlords was not found automatically. Enter its installation folder, or press Enter to cancel'
  if ($manual -and (Test-Path (Join-Path $manual $UnitsRel))) { return (Resolve-Path $manual).Path }
  throw 'Underlords installation was not found.'
}
function Check-AssetPackage($Root) {
  $package = Get-Content (Join-Path $Base 'appearance\package.json') -Raw | ConvertFrom-Json
  $assetSource = Join-Path $Base 'appearance\files'
  $installed = @()
  foreach ($asset in $package.assets) {
    $source = Join-Path $assetSource ($asset.path -replace '/', '\')
    if (!(Test-Path -LiteralPath $source)) { throw "Package asset is missing: $($asset.path)" }
    if ((Hash $source) -ne $asset.sha256.ToLowerInvariant()) { throw "Package asset hash mismatch: $($asset.path)" }
    $destination = Join-Path $Root ('game\dac\' + ($asset.path -replace '/', '\'))
    if (Test-Path -LiteralPath $destination) { throw "Existing asset conflict: $destination" }
    $installed += [pscustomobject]@{ path=$asset.path; sha256=$asset.sha256.ToLowerInvariant() }
  }
  return $installed
}
function Write-State($Value) {
  New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
  $Value | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $StatePath -Encoding UTF8
}

try {
  Stop-IfRunning
  $Root = Find-Game
  if (Test-Path -LiteralPath $StatePath) {
    $old = Get-Content $StatePath -Raw | ConvertFrom-Json
    if ($old.status -eq 'applied') { throw 'This package is already applied. Restore it before applying again.' }
  }
  $units = Join-Path $Root $UnitsRel; $items = Join-Path $Root $ItemsRel
  if ((Hash $units) -ne $OriginalUnits -or (Hash $items) -ne $OriginalItems) { throw 'Unexpected Underlords build or file hash. Nothing was changed.' }
  $candidateUnits = Join-Path $Base 'candidates\units.vdacdefs_c'; $candidateItems = Join-Path $Base 'candidates\items.vdacdefs_c'
  if ((Hash $candidateUnits) -ne $CandidateUnits -or (Hash $candidateItems) -ne $CandidateItems) { throw 'Package candidate hash mismatch. Nothing was changed.' }
  $assets = Check-AssetPackage $Root
  $backupUnits = Join-Path $StateDir 'units.original.vdacdefs_c'; $backupItems = Join-Path $StateDir 'items.original.vdacdefs_c'
  Copy-Item -LiteralPath $units -Destination $backupUnits; Copy-Item -LiteralPath $items -Destination $backupItems
  if ((Hash $backupUnits) -ne $OriginalUnits -or (Hash $backupItems) -ne $OriginalItems) { throw 'Backup verification failed. Nothing was installed.' }
  $state = [pscustomobject]@{ status='preparing'; root=$Root; units=$UnitsRel; items=$ItemsRel; assets=$assets; original_units=$OriginalUnits; original_items=$OriginalItems; candidate_units=$CandidateUnits; candidate_items=$CandidateItems }
  Write-State $state
  try {
    Copy-Item -LiteralPath $candidateUnits -Destination $units -Force
    Copy-Item -LiteralPath $candidateItems -Destination $items -Force
    foreach ($asset in $assets) {
      $source = Join-Path (Join-Path $Base 'appearance\files') ($asset.path -replace '/', '\')
      $destination = Join-Path $Root ('game\dac\' + ($asset.path -replace '/', '\'))
      New-Item -ItemType Directory -Force -Path (Split-Path $destination) | Out-Null
      Copy-Item -LiteralPath $source -Destination $destination
    }
    if ((Hash $units) -ne $CandidateUnits -or (Hash $items) -ne $CandidateItems) { throw 'Installed definition verification failed.' }
    $state.status = 'applied'; Write-State $state
  } catch {
    if (Test-Path $backupUnits) { Copy-Item $backupUnits $units -Force }
    if (Test-Path $backupItems) { Copy-Item $backupItems $items -Force }
    foreach ($asset in $assets) { $destination = Join-Path $Root ('game\dac\' + ($asset.path -replace '/', '\')); if (Test-Path $destination) { Remove-Item $destination -Force } }
    throw
  }
  Write-Host 'Crazy offline build applied. Launching a new local/bot game.' -ForegroundColor Green
  $steam = Join-Path ${env:ProgramFiles(x86)} 'Steam\steam.exe'
  if (!(Test-Path $steam)) { $steam = Join-Path $env:ProgramFiles 'Steam\steam.exe' }
  if (!(Test-Path $steam)) { throw 'Steam.exe was not found. The build is applied; start Steam and launch Underlords with -dac_offline.' }
  Start-Process -FilePath $steam -ArgumentList '-applaunch','1046930','-dac_offline'
} catch { Write-Host ('REFUSED: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }
